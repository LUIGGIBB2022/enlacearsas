<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DetalledelistaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
