 <div class="container contenedor_botones_i">
      <a href="{{ route('contenidos.edit',$id) }}" <i class='far fa-edit fa-2x boton_edit' title="Editar Registro"</i></a>
      <a href="{{ route('contenidos.delete',$id) }}" <i class="fas fa-trash-alt fa-2x boton_del" title="Eliminar Registro"></i></a>
 </div>
