<footer class="footer" >
    <div class="container" style="background-color: blueviolet !important">
        <nav class="float-left">
        <div class="copyright float-right ">
            Derechos Reservados &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, Design By CIS DE LA COSTA <i class="material-icons"></i>
            <a href="#" target="_blank"></a><a href="#" target="_blank"></a>
        </div>
    </div>
</footer>
