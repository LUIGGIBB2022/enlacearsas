<footer class="footer" id="pie_pagina_auth">
  <div class="container-fluid">
    <nav class="float-left">
      <ul>
        <li>
          <a href="#">
              {{ __('Enlace Visual') }}
          </a>
        </li>
        <li>
          <a href="https://creative-tim.com/presentation">
              {{ __('Acerca de') }}
          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright float-right">
      Derechos Reservados &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, Design By CIS DE LA COSTA <i class="material-icons"></i>
      <a href="#" target="_blank"></a><a href="#" target="_blank"></a>
    </div>
  </div>
</footer>
