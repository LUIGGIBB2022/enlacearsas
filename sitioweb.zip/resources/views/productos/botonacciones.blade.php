<a href="{{ route('productos.edit',$productoID) }}" class="btn btn-info btn-sm botoneditar" style="font-size:9px; background:rgb(238, 16, 16);">Editar</a>
