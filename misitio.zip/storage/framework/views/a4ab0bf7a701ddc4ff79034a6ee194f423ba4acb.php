 
 

<?php $__env->startSection('content'); ?>


	<div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="lnr-user icon-gradient bg-warm-flame"></i>
                    
                </div>

            </div>
        </div>
    </div>

    <div class="p-large">
        <div class="content">
            <div class="desarrollo">
                <img src="<?php echo e(asset('img/bannercan.png')); ?>">
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.menu02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\enlacearsas\resources\views/home/home.blade.php ENDPATH**/ ?>