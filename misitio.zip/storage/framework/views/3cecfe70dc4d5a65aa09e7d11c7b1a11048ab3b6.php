<!DOCTYPE doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
            <meta content="width=device-width, initial-scale=1" name="viewport">
                <!-- CSRF Token -->
                <meta content="<?php echo e(csrf_token()); ?>" name="csrf-token">
                    <!--<title>
                        <?php echo e(config('app.name', 'Enlace Visual')); ?>

                    </title> -->
                    <title>Enlace Visual</title>
                    <?php echo $__env->yieldContent('css'); ?>
                    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/normalize.min.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/bootstrap.min.css')); ?>" />
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/font-awesome.min.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/themify-icons.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/flag-icon.min.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/cs-skin-elastic.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('strokecss/css/pe-icon-7-stroke.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/cs-skin-elastic.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/style.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/chart/chartist.min.css')); ?>" rel="stylesheet">
                    <link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
                    <?php echo $__env->yieldContent('styles'); ?>
                </meta>
            </meta>
        </meta>
        <style>
           #weatherWidget .currentDesc
           {
             color: #ffffff!important;
           }
           .traffic-chart
           {
             min-height: 335px;
           }
           #flotPie1  {
              height: 150px;
            }
            #flotPie1 td {
              padding:3px;
            }
            #flotPie1 table {
               top: 20px!important;
               right: -10px!important;
            }
            .chart-container {
                display: table;
                min-width: 270px ;
                text-align: left;
                padding-top: 10px;
                padding-bottom: 10px;
            }
            #flotLine5  {
                height: 105px;
           }

           #flotBarChart {
               height: 150px;
           }
           #cellPaiChart{
               height: 160px;
           }
           .menu-icon
           {
             font-size:18px !important;
             color:#6C3483 !important;
           }

           .sub-menu
           {
            padding-top:0.01ch !important;
            padding-bottom: 0.01ch !important;
            margin-top:-0.1ch !important;
           }
           .menu-title
           {
             text-align: center;
             color:rgb(17, 161, 228);
           }
           .color-header
           {
               background-color: #d8d8da !important;
           }
        </style>
    </head>
    <body>
        <div class="alerta-app <?php if(session('status')): ?> active <?php endif; ?>">
             <p>
                <?php echo e(session('status')); ?>

            </p>
        </div>
        <div class="app-container app-theme-white body-tabs-shadow fixed-header fixed-sidebar">
            <?php if(auth()->guard()->guest()): ?>
                <?php echo $__env->yieldContent('content'); ?>
            <?php else: ?>
                <div class="app-main">
                    <?php echo $__env->make('template.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="app-main__outer">
                        <div class="app-main__inner">
                            <?php echo $__env->yieldContent('contenedor'); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>

<?php /**PATH C:\wamp64\www\pedidosmap\resources\views/layouts/app.blade.php ENDPATH**/ ?>