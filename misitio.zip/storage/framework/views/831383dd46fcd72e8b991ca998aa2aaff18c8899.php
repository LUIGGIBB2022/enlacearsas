<!DOCTYPE doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
            <meta content="width=device-width, initial-scale=1" name="viewport">
                <!-- CSRF Token -->
                <meta content="<?php echo e(csrf_token()); ?>" name="csrf-token">
                    <!--<title>
                        <?php echo e(config('app.name', 'Enlace Visual')); ?>

                    </title> -->
                    <?php echo $__env->yieldContent('css'); ?>
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/normalize.min.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/bootstrap.min.css')); ?>" />
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/font-awesome.min.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/themify-icons.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/flag-icon.min.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/cs-skin-elastic.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('strokecss/css/pe-icon-7-stroke.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/cs-skin-elastic.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/style.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/configurarheader.css')); ?>">
                    <link rel="stylesheet" href="<?php echo e(asset('css/menuside/chart/chartist.min.css')); ?>" rel="stylesheet">
                </meta>
            </meta>
        </meta>

    </head>
    <body>
        <div class="alerta-app <?php if(session('status')): ?> active <?php endif; ?>">
            <span>
            </span>
            <p>
                <?php echo e(session('status')); ?>

            </p>
        </div>
        <div class="app-container app-theme-white body-tabs-shadow fixed-header fixed-sidebar">
            <?php if(auth()->guard()->guest()): ?>

               <?php echo $__env->make('auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <?php else: ?>
            
            <div class="app-main">
                <?php echo $__env->make('template.partials.menuhome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <?php echo $__env->yieldContent('contenedor'); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>






<?php /**PATH C:\wamp64\www\enlacearsas\resources\views/layouts/menu02.blade.php ENDPATH**/ ?>