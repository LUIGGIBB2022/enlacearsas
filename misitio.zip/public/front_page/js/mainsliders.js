$(window).load(function() {
	$('#myCarousel').carousel({
  		interval: 3000
 		})
   	});
