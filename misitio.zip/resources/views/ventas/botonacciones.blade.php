<a href="{{ route('ventas.verdetalle',['id'=>$id,'prefijo'=>$prefijo]) }}"  class="btn btn-info btn-sm botoneditar" style="font-size:9px; background:rgb(238, 16, 16);">Detalle</a>


